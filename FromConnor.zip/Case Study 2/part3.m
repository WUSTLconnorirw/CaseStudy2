load("mockdata_v2.mat");

%find fit for mock data
%Y_fit_infection%%%%%%%%%%%%%%%%%%%%%%%%
%days 1 to 100%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
td = 1:100;
t = length(td);
coviddata = [InfectedProportion(td).' cumulativeDeaths(td).'];

sirafun= @(x)siroutput_v(x,t,coviddata);

A = [];  
b = [];
Af = [0 0 0 0 0 1 1 1 1 1];
bf = 1;
ub = []';
lb = []';
x0 = [0.05, 0.01, 0.01, 0.01, 0.00001 0.999, 0.001,0,0,0]; 

x = fmincon(sirafun,x0,A,b,Af,bf,lb,ub);
Y_fit1 = siroutput_v_full(x,t);


%days 101 to 200%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
td = 101:200;
t = length(td);
coviddata = [InfectedProportion(td).' cumulativeDeaths(td).'];

sirafun= @(x)siroutput_v(x,t,coviddata); 

x = fmincon(sirafun,x0,A,b,Af,bf,lb,ub);
Y_fit2 = siroutput_v_full(x,t);

%days 200 to 365%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
td = 200:365;
t = length(td);
coviddata = [InfectedProportion(td).' cumulativeDeaths(td).'];

sirafun= @(x)siroutput_v(x,t,coviddata); 

x = fmincon(sirafun,x0,A,b,Af,bf,lb,ub);
Y_fit3 = siroutput_v_full(x,t);

%Combine Y_fit%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
td = 1:365;
t = length(td);
coviddata = [InfectedProportion(td).' cumulativeDeaths(td).'];
Y_fit = cat(1,Y_fit1,Y_fit2,Y_fit3);


figure();
hold on;
l1 = plot(td,(ones([t,1])'-Y_fit(1:t,1)-Y_fit(1:t,5)),'green');
l2 = plot(td,Y_fit(1:t,4),'black');
l3 = plot(coviddata(:,1),'r');
l4 = plot(coviddata(:,2),'blue');
legend([l1(1),l2,l3,l4],"Simulated Infected", "Simulated Deaths", "Actual Infected", "Actual Death")
ylabel("Fraction Population");
xlabel("Days");
title("Actual Data and Fit(Days 10-110)","FontSize",14)
ylim([0 0.1]);
grid on
hold off;
